Aiove GitHub 直运行版

目录结构：
- Aiove.lua                         主 UI
- 01_Aiove_DOORS.lua ... 65_Aiove_鲨口求生.lua   其他服务器独立脚本
- 99_Aiove_圣奥里.lua               圣奥里独立脚本

GitHub 使用要求：
1. 将本目录中的所有 Lua 文件上传到你的仓库：
   https://github.com/AioveCN/RobloxScripts
2. 文件放在 main 分支的仓库根目录，不要放进子文件夹。
3. 确认 GitHub 上每个文件名与本目录完全一致，包括中文文件名。
4. 直接执行 Aiove.lua 的 Raw 地址即可；主 UI 会从 GitHub Raw 自动加载对应独立模块。

主脚本 Raw：
https://raw.githubusercontent.com/AioveCN/RobloxScripts/main/Aiove.lua

执行：
loadstring(game:HttpGet("https://raw.githubusercontent.com/AioveCN/RobloxScripts/main/Aiove.lua"))()

说明：
- Aiove.lua 不再依赖 readfile 才能加载独立模块。
- 模块加载优先使用 GitHub Raw；GitHub 请求失败时才尝试本地 readfile。
- 顶层 UI 保持四项：信息、通用、圣奥里、其他服务器脚本。
- 其他服务器脚本保持独立文件，不把 65 个源码拼接进 Aiove.lua。
- 99_Aiove_圣奥里.lua 单独作为圣奥里脚本。
